# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re

import requests
from lxml import etree
from werkzeug import urls

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError


class jigyasa(models.Model):

    _inherit = "res.partner"
    
    child_name = fields.Char(index=True)
    guardian_id = fields.Many2one('res.partner', string='Related Guardian or Parents', index=True)
    guardian_name = fields.Char(related='guardian_id.name', readonly=True, string='Parent name')
    child_ids = fields.One2many('res.partner', 'guardian_id', string='Contact', domain=[('active', '=', True)])  # force "active_test" domain to bypass _search() override
    user_id = fields.Many2one('res.users', string='Teaching person',
      help='The internal user in charge of this contact.')
    is_guardian = fields.Boolean(string='Is a Gaurdian', default=False,
        help="Check if the contact is a Parent, otherwise it is a Studnet") 
    # student_type is only an interface field, do not use it in business logic
    student_type = fields.Selection(string='Company Type',
        selection=[('person', 'Individual'), ('Gaurdian', 'Gaurdian'),('School', 'School')],
        compute='_compute_student_type', inverse='_write_student_type')
    
@api.depends('is_guardian')
def _compute_student_type(self):
    for partner in self:
        partner.student_type = 'company' if partner.is_company else 'person'