# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re
from datetime import date
from dateutil.relativedelta import relativedelta
import requests
from lxml import etree
from werkzeug import urls
import time
from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError

class psittacus(models.Model):
    _description = 'Student Contact'
    _inherit = "res.partner"

    is_guardian = fields.Boolean(string='Is a Guardian', domain="[('is_guardian', '=', True)]",)
    #company_type = fields.Selection(string='Enrollment Type',selection=[('person', 'Student'), ('company', 'Guardian')])
    enrollment_type = fields.Selection(string='Enrollment Type',selection=[('student', 'Student'), ('guardian', 'Guardian')], compute='_compute_enrollment_type', inverse='_write_enrollment_type')
    #company_type = fields.Selection(selection_add=[('guardian', 'guardian')])
    guardian_id = fields.Many2one('res.partner', string='guardian', index=True, )
    guardian_name = fields.Char(string='guardian name', store=True, related='guardian_id.name')
    birth_date = fields.Date(string='Birth Date', default=time.strftime('1990-01-01'))
    school_name = fields.Char(string='school name',)
    age = fields.Char(string='Age', store=True, compute='_cal_age')
    gender = fields.Selection(
        string='Gender',
        selection=[('male', 'male'), ('female', 'female'), ('other','other')], )
     
    @api.depends('is_guardian')
    def _compute_enrollment_type(self):
        for partner in self:
            partner.enrollment_type = 'guardian' if partner.is_guardian else 'student'
            
    def _write_enrollment_type(self):
        for partner in self:
            partner.is_guardian = partner.enrollment_type == 'guardian'
            
    @api.onchange('enrollment_type')
    def onchange_company_type(self):
        self.is_company = (self.enrollment_type == 'student')
        self.is_guardian = (self.enrollment_type == 'guardian')

    def create_guardian(self):
        self.ensure_one()
        if self.guardian_name:
            # Create parent company
            values = dict(name=self.guardian_name, is_guardian=True, vat=super.vat)
            values.update(super._update_fields_values(super._address_fields()))
            new_guardian = self.create(values)
            # Set new company as my parent
            self.write({
                'parent_id': new_guardian.id,
                'child_ids': [(1, guardian_id, dict(parent_id=new_guardian.id)) for guardian_id in self.child_ids.ids]
            })
        return True
    

    @api.onchange('birth_date')
    @api.depends('birth_date')
    def _cal_age(self):
        today = date.today()
        for record in self:
            age = []
            dob = fields.Date.from_string(record.birth_date)
            gap = relativedelta(today, dob)
            if gap.years > 0:
                record.age = str(gap.years) + ' Years'
            else:
                raise UserError(_('Birth Date must be Low than the Current Date'))
    
    