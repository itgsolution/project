# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
## Developed By Psittacuslab 
import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re
from datetime import date
from dateutil.relativedelta import relativedelta
import requests
from lxml import etree
from werkzeug import urls
import time
from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError


class psittacus(models.Model):
    _description = 'Student Contact'
    _inherit = "res.partner"
    company_type =  fields.selection_add=[('guardian', guardian),('school',school)]
    
    #enrollmenttype = fields.Selection(string='enrollment Type',
    #    selection=[('person', 'Individual'), ('company', 'company'), ('guardian', 'Guardian'), ('school', 'School')],
    #    compute='_compute_enrollment_type', inverse='_write_enrollment_type')
    ## Gaurdian Details
    guardian_id = fields.Many2one('res.partner', string='guardian', index=True, )
    is_guardian = fields.Boolean(string='Is a Guardian', domain="[('is_guardian', '=', True)]",)
    is_school = fields.Boolean(string='Is a School', domain="[('is_school', '=', True)]",)
    is_company = fields.Boolean(string='Is a Company', domain="[('is_company', '=', True)]",)
    is_person = fields.Boolean(string='Is a Individual', domain="[('is_person', '=', True)]",)
    
    
    school_name = fields.Char(string='school name',)
    principal_name = fields.Char(string='principal name',)
    company_name = fields.Char(string='company name',)
    guardian_name = fields.Char(string='parent name',)

    birth_date = fields.Date(string='Birth Date', default=time.strftime('1990-01-01'))
    #age = fields.Integer(string='Age (In Years)', store=True, compute='_cal_age')
    gender = fields.Selection(string='Gender', selection=[('male', 'male'), ('female', 'female'), ('other','other')], default = 'other')  

    @api.depends('is_company','is_person','is_guardian','is_school')
    #@api.onchange('enrollmenttype')
    def _compute_enrollment_type(self):
        for partner in self:
            print(partner.is_school)
            if partner.is_school == True:
                partner.enrollmenttype = 'school'
                print(partner.enrollmenttype)
            else:
                pass
                #partner.enrollmenttype = 'company' if partner.is_company else 'person'
            

    def _write_enrollment_type(self):
        for partner in self:
            partner.is_company = partner.enrollmenttype == 'company'

    @api.onchange('enrollmenttype')
    def onchange_enrollment_type(self):
        self.is_company = (self.enrollmenttype == 'company')
        self.is_guardian = (self.enrollmenttype == 'guardian')
        self.is_school = (self.enrollmenttype == 'school')
        self.is_person = (self.enrollmenttype == 'person')
        
    #@api.onchange('enrollmenttype')
    #def _compute_enrollment_type(self):
    #    for partner in self:
    #       if partner.is_guardian:
    #            partner.enrollmenttype == 'guardian'
    #        
    #        else:
    #           partner.enrollmenttype == 'person'
            #partner.enrollmenttype = 'guardian' if partner.is_guardian
            #partner.enrollmenttype = 'company' if partner.is_company
            #partner.enrollmenttype = 'school' if partner.is_company else 'person'
            
           
            
    def _write_enrollment_type(self):
        for partner in self:
            partner.is_guardian = partner.enrollmenttype == 'guardian'
            partner.is_person = partner.enrollmenttype == 'individual'
            partner.is_school = partner.enrollmenttype == 'school'
            partner.is_student = partner.enrollmenttype == 'student'
            
    @api.onchange('enrollmenttype')
    def onchange_company_type(self):
        self.is_company = (self.enrollmenttype == 'student')
        self.is_guardian = (self.enrollmenttype == 'guardian')
        self.is_school = (self.enrollmenttype == 'school')
        self.is_person = (self.enrollmenttype == 'individual')


    def create_guardian(self):
        self.ensure_one()
        if self.guardian_name:
            # Create parent company
            values = dict(name=self.guardian_name, is_guardian=True, vat=super.vat)
            values.update(super._update_fields_values(super._address_fields()))
            new_guardian = self.create(values)
            # Set new company as my parent
            self.write({
                'parent_id': new_guardian.id,
                'child_ids': [(1, guardian_id, dict(parent_id=new_guardian.id)) for guardian_id in self.child_ids.ids]
            })
        return True
    

    @api.onchange('birth_date')
    @api.depends('birth_date')
    def _cal_age(self):
        today = date.today()
        for record in self:
            age = []
            dob = fields.Date.from_string(record.birth_date)
            gap = relativedelta(today, dob)
            if gap.years > 0:
                record.age = int(gap.years)
            else:
                raise UserError(_('Birth Date must be Low than the Current Date'))
    
    