# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re

import requests
from lxml import etree
from werkzeug import urls

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError

class guardianname(models.Model):
    _name='gaurdian.name'
    _description='guardian names'
    name = fields.Char(string='guardian name', required=True)
class psittacus(models.Model):
    _description = 'Student Contact'
    _inherit = "res.partner"
    is_guardian = fields.Char(string='are you guardian')
    guardian_id = fields.Many2one('guardian.name', string='guardian name')
    gender = fields.Selection([('male', 'Male'),('fe_male', 'Female'),], default='male', string="Gender")
    age = fields.Date(string='age', default=fields.Date.context_today,)
    company_type = fields.Selection(selection_add=[('Gurdian', 'Guardian')])
    
    @api.onchange('guardian_name')
    def onchange_guardian_name(self):
        for rec in self:
            if rec.guardian_name:
                rec.guardian_name = rec.guardian_name

    
    @api.depends('is_company')
    def _compute_company_type(self):
        for partner in self:
            partner.company_type = 'company' if partner.is_company else 'person'
            partner.company_type = 'guardian' if partner.is_guardian else 'person'
        

    def _write_company_type(self):
        for partner in self:
            partner.is_company = partner.company_type == 'company'
            partner.is_guardian = partner.company_type == 'guardian'

    @api.onchange('company_type')
    def onchange_company_type(self):
        self.is_company = (self.company_type == 'company')
        self.is_guardian = (self.company_type == 'guardian')

   
    
