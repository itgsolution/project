# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
## Developed By Psittacuslab 
import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re
from datetime import date
from dateutil.relativedelta import relativedelta
import requests
from lxml import etree
from werkzeug import urls
import time
from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError

class Jigyasa(models.Model):
    _description = 'Jigyasa Informations Details'
    _name = 'jigyasa.partner'
    
    
    school_name = fields.Char(string='School Name',)
    #school_name = fields.Many2one('res.partner', string='School Name', index=True,)
    #school_principal = fields.Char(string='Principal Name',)
    #school_email = fields.Char(string='School Email Address',)
    #school_phone = fields.Char(string='School Phone',)
    #school_ref = fields.Char(string='Reference or Coordinator',)
    #guardian_name = fields.Char(string='Guardian Name',)
    #guardian_email = fields.Char(string='Guardian Email Address',)
    #guardian_phone = fields.Char(string='Guardian Contact ',)
    #teacher_name = fields.Char(string='Name of Teacher',)
    #coordinator_name = fields.Char(string='Coordinator',)
    def create_school(self):
       self.ensure_one()
       if self.school_name:
           # Create parent company
           values = dict(name=self.school_name, is_school=True, vat=self.vat)
           values.update(self._update_fields_values(self._address_fields()))
           new_school = self.create(values)
           # Set new company as my parent
           self.write({
               'parent_id': new_school.id,
               'child_ids': [(1, partner_id, dict(parent_id=new_school.id)) for partner_id in self.child_ids.ids]
           })
       return True