# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import collections
import datetime
import hashlib
import pytz
import threading
import re

import requests
from lxml import etree
from werkzeug import urls

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.modules import get_module_resource
from odoo.osv.expression import get_unaccent_wrapper
from odoo.exceptions import UserError, ValidationError

class psittacus(models.Model):
    _description = 'Student Contact'
    _inherit = "res.partner"

    is_guardian = fields.Char(string='Are You Guardian')
    guardian_id = fields.Many2one('res.partner', string='Guardian Name')
    guardian_name = fields.Char('Guardian Name')
    gender = fields.Selection([('male', 'Male'),('fe_male', 'Female'),], default='male', string="Gender")
    age = fields.Date(string='age', default=fields.Date.context_today,)
    company_type = fields.Selection(selection_add=[('guardian', 'Guardian')])

    def create_guardian(self):
        self.ensure_one()
        if self.guardian_name:
            # Create Guardian
            values = dict(name=self.guardian_name, is_guardian=True, vat=self.vat)
            values.update(self._update_fields_values(self._address_fields()))
            new_guardian = self.create(values)
            # Set new company as my parent
            self.write({
                'guardian_id': new_guardian.id,
                'child_ids': [(1, guardian_id, dict(guardian_id=new_guardian.id)) for guardian_id in self.child_ids.ids]
            })
        return True    
<?xml version="1.0" encoding="utf-8"?>
<odoo>
       <record id="view_partner_simple_form" model="ir.ui.view">
            <field name="name">res.partner.simplified.form</field>
            <field name="model">res.partner</field>
            <field name="inherit_id" ref="base.view_partner_form"/>
            <field name="arch" type="xml">
            
            <xpath expr="//field[@name='is_company']" position="after">
                <field name="is_guardian" invisible="1"/>
                           
            </xpath>
            <xpath expr="//field[@name='parent_id']" position="after">
                 <field name="guardian_id"
                            widget="res_partner_many2one"
                            placeholder="Guardian Name"
                            domain="[('is_company', '=', True)]" context="{'default_is_company': True, 'show_vat': True}"
                            attrs="{'invisible': [('is_company','=', True)]}"/>
            </xpath>
                        
            
            
            
            
           
            
            </field>
        </record>
</odoo>
   
    
